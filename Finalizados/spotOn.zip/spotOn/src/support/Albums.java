package support;

public class Albums {
	public String idCantor;
	public String idGenero;
	public String nomeAlbum;
	public String ano;
	public String idAlbum;
	
	public Albums(String idCantor, String idGenero, String nomeAlbum,String ano,String idAlbum){
			this.idCantor=idCantor;
			this.idGenero=idGenero;
			this.nomeAlbum=nomeAlbum;
			this.ano=ano;
			this.idAlbum=idAlbum;
	}
	
}
