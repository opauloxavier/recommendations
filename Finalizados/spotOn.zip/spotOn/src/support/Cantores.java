package support;

public class Cantores {

	public String nomeCantor;
	public String descricaoCantor;
	public String nomeFoto;
	public String generoCantor;
	public String idCantor;
	
	public Cantores(String nomeCantor, String descricaoCantor, String nomeFoto){
			this.nomeCantor=nomeCantor;
			this.descricaoCantor=descricaoCantor;
			this.nomeFoto=nomeFoto;
	}
	
	public Cantores(String nomeCantor, String descricaoCantor, String nomeFoto,String generoCantor){
		this.nomeCantor=nomeCantor;
		this.descricaoCantor=descricaoCantor;
		this.nomeFoto=nomeFoto;
		this.generoCantor=generoCantor;
	}
	
	public Cantores(String nomeCantor, String descricaoCantor, String nomeFoto,String generoCantor,String idCantor){
		this.nomeCantor=nomeCantor;
		this.descricaoCantor=descricaoCantor;
		this.nomeFoto=nomeFoto;
		this.generoCantor=generoCantor;
		this.idCantor=idCantor;
	}
	
}
