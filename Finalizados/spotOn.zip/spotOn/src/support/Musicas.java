package support;

public class Musicas {
	
		public String nomeMusica;
		public String nomeCantor;
		public int idGenero;
		
		public Musicas(String Musica, String Cantor, int idGenero){
				this.nomeMusica=Musica;
				this.nomeCantor=Cantor;
				this.idGenero=idGenero;
		}

}
