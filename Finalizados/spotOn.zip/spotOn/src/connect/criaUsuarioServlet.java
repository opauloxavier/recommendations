package connect;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
@WebServlet("/criaUsuarioServlet")
public class criaUsuarioServlet extends HttpServlet {
        
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
    	if(request.getParameter("password").compareTo(request.getParameter("passwordAgain"))==0){
	    	try {
				if(connectDB.efetuaCadastro(request.getParameter("email"),request.getParameter("nome"), request.getParameter("password"))){
					response.sendRedirect("cadastro.jsp?erro=0"); //Usuário Criado com sucesso
				}
					
				else{
					response.sendRedirect("cadastro.jsp?erro=1");//Usuario Já existe
				}
					
			} catch (SQLException e) {
				//Caguei
				e.printStackTrace();
			}
    	}
    	else{
    		 response.sendRedirect("cadastro.jsp?erro=2"); //Senhas nao conferem
    	}
    }
 
}