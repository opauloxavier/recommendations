package connect;
import java.io.IOException;
import connect.connectDB;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
@WebServlet("/criaAlbumServlet")
public class criaAlbumServlet extends HttpServlet {
        
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	if(request.getParameter("nomeAlbum") !=null && request.getParameter("anoAlbum")!=null ){
	    	try {
				if(connectDB.incluiAlbum(request.getParameter("idCantor"), request.getParameter("idGenero"),request.getParameter("nomeAlbum"),request.getParameter("anoAlbum"))){
					response.sendRedirect("insereData.jsp?cantor="+request.getParameter("idCantor")+"&erro=0"); //Criado com sucesso
				}
					
				else{
					response.sendRedirect("insereData.jsp?cantor="+request.getParameter("idCantor")+"&erro=1");//Elemento já existe
				}
				
	    		System.out.println(request.getParameter("album"));
					
			} catch (SQLException e) {
				//Caguei
				e.printStackTrace();
			}
    	}
    	else{
    		response.sendRedirect("insereData.jsp?cantor="+request.getParameter("idCantor")+"&erro=2"); //Dados Incompletos
    	}
    }
 
}