package connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import support.Musicas;
import support.Cantores;
import support.Albums;

public class connectDB {
	
	 public static Connection conn = null;
	 
	 public static void connect(){
		 if (conn == null) {
			 
				try {
					Class.forName("com.mysql.jdbc.Driver");
				} catch (ClassNotFoundException e) {
					System.out.println("Where is your MySQL JDBC Driver?");
					e.printStackTrace();
					return;
				}
				try {
				
					conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/px_recommendations","root", "over5574");
	
				} catch (SQLException e) {
					System.out.println("Connection Failed! Check output console");
					e.printStackTrace();
					return;
				}
				
				if (conn != null) {
					//System.out.println("Conexão OK");
				} else {
					System.out.println("Erro ao acessar o Banco");
				}
		 }
		 
		 else{
			 System.out.println("Ja conectou");
		 }
			
	 }
	 
	 public static ResultSet doQuery(String Query) throws SQLException{
		 
			if(conn==null) {
				connect();
			}
		 
		 Statement stmt = null;
		 ResultSet results = null;
		 try{
		 	stmt = conn.createStatement();
		    results = stmt.executeQuery(Query);
		 }
		 
		 catch (SQLException e ) {
			 	System.out.println(e);
		    }
		 
		 finally{
			 // if (stmt != null) {
				//  stmt.close();
			//}
		 }
		    return results;
	 }
	 
	 
	 public static Cantores getCantor(String ID) throws SQLException{
			if(conn==null) {
				connect();
			}
			
			Cantores cantor=null;
			
			 ResultSet results = doQuery("Select * from px_cantores Where ID='"+ID+"'");
			 
			 while (results.next()) {
				cantor = new Cantores(results.getString("nome_cantor"),results.getString("descricao"),results.getString("nomeFoto"),results.getString("ID_genero"));
		        }
			 
			 return cantor;
		 }
	 
	 public static ArrayList<Cantores> getCantores() throws SQLException{
		if(conn==null) {
			connect();
		}
		 
		 ArrayList<Cantores> cantores = new ArrayList<Cantores>();
		
		 ResultSet results = doQuery("Select * from px_cantores");
		 
		 while (results.next()) {
			 Cantores a = new Cantores(results.getString("nome_cantor"),results.getString("descricao"),results.getString("nomeFoto"),results.getString("ID_genero"),results.getString("ID"));
	 		 	cantores.add(a);
	        }
		 
		 return cantores;
	 }
	 
	 public static ArrayList<Musicas> getMusicas(String cantor) throws SQLException{
		
		 if(conn==null) {
				connect();
			}
		 
		 ResultSet results = doQuery("SELECT * FROM px_musicas,px_cantores where nome_cantor='"+cantor+"' and ID_cantor = px_cantores.ID");
		 
		 ArrayList<Musicas> musica = new ArrayList<Musicas>();
		 
		 while (results.next()) {
			 	Musicas a = new Musicas(results.getString("nome_musica"),results.getString("nome_cantor"),results.getInt("ID_genero"));
	 		 	musica.add(a);
	        }
		 
		 return musica;
	 }
	 
	 public static ArrayList<String> getGeneros() throws SQLException{
			
		 if(conn==null) {
				connect();
			}
		 
		 ResultSet results = doQuery("select nome_genero from px_generos");
		 
		 ArrayList<String> generos = new ArrayList<String>();
		 
		 while (results.next()) {
	 		 	generos.add(results.getString("nome_genero"));
	        }
		 
		 return generos;
	 }
	 
	 public static String getGeneroCantor(String idGenero) throws SQLException{
			
		 if(conn==null) {
				connect();
			}
		 
		 ResultSet results = doQuery("select nome_genero from px_generos where ID='"+idGenero+"'");
		 
		 String genero = "";
		 
		 while (results.next()) {
	 		 	genero=results.getString("nome_genero");
	        }
		 
		 return genero;
	 }
	 
	 public static ArrayList<Albums> getFullAlbum(String idCantor) throws SQLException{
			
		 if(conn==null) {
				connect();
			}
		 
		 ResultSet results = doQuery("select * from px_albuns where ID_cantor='"+idCantor+"'");
		 
		 ArrayList<Albums> albuns = new  ArrayList<Albums>();
		 
		 while (results.next()) {
			 Albums album = new Albums(results.getString("ID_cantor"),results.getString("ID_genero"),results.getString("nome_album"),results.getString("ano"),results.getString("ID"));
			 albuns.add(album);
	        }
		 
		 return albuns;
	 }
	 
	 public static ArrayList<String> getAlbumCantor(String idCantor) throws SQLException{
			
		 if(conn==null) {
				connect();
			}
		 
		 ResultSet results = doQuery("select nome_album from px_albuns where ID_cantor='"+idCantor+"'");
		 
		 ArrayList<String> albuns = new  ArrayList<String>();
		 
		 while (results.next()) {
			 String album = results.getString("nome_album");
			 albuns.add(album);
	        }
		 
		 return albuns;
	 }
	 
	 
	 public static boolean efetuaLogin(String email, String Senha) throws SQLException{
		 
		 if(conn==null) {
				connect();
		}
		 
		 int numeroOcorrencia=0;
		 
		 ResultSet results = doQuery("SELECT COUNT(*) as total from px_user WHERE email='"+email+"' and password ='"+Senha+"'");
		 
		 while (results.next()) {
	 		 	numeroOcorrencia= results.getInt("total");
	        }
		 
		 if (numeroOcorrencia>0)
		 	return true;
		 
		 else
			 return false;
	 }
	 
	public static boolean efetuaCadastro(String email,String nome, String senha) throws SQLException{
		 if(conn==null) {
				connect();
		}
		 
		 int numeroOcorrencia=0;
		 
		 ResultSet results = doQuery("SELECT COUNT(*) as total from px_user WHERE email='"+email+"'");
		 
		 while (results.next()) {
	 		 	numeroOcorrencia= results.getInt("total");
	        }
		 
		 if(numeroOcorrencia==0){
			 Statement statement = null;
			 
			 statement = conn.createStatement();
			 
			 String insertTableSQL ="INSERT INTO px_user (ID, email,nome, password) VALUES (NULL, '"+email+"', '"+nome+"', '"+senha+"')";
			 
			 statement.executeUpdate(insertTableSQL);
			 
			 return true;
		 }
		 
		 else
			 return false;
		 
	 }
	
	public static boolean incluiMusica(String id_cantor,String id_album, String id_genero, String nome_musica) throws SQLException{
		 if(conn==null) {
				connect();
		}
		 
		 int numeroOcorrencia=0;
		 
		 ResultSet results = doQuery("SELECT COUNT(*) as total from px_musicas WHERE nome_musica='"+nome_musica+"'");
		 
		 while (results.next()) {
	 		 	numeroOcorrencia= results.getInt("total");
	        }
		 
		 if(numeroOcorrencia==0){
			 Statement statement = null;
			 
			 statement = conn.createStatement();
			 
			 String insertTableSQL ="INSERT INTO px_musicas (ID,ID_cantor, ID_album,ID_genero,nome_musica) VALUES (NULL, '"+id_cantor+"', '"+id_album+"', '"+id_genero+"','"+nome_musica+"')";

			 statement.executeUpdate(insertTableSQL);
			 
			 return true;
		 }
		 
		 else
			 return false;
		 
	 }
	
	public static boolean incluiAlbum(String id_cantor, String id_genero, String nome_album,String ano) throws SQLException{
		 if(conn==null) {
				connect();
		}
		 
		 int numeroOcorrencia=0;
		 
		 ResultSet results = doQuery("SELECT COUNT(*) as total from px_albuns WHERE nome_album='"+nome_album+"'");
		 
		 while (results.next()) {
	 		 	numeroOcorrencia= results.getInt("total");
	        }
		 
		 if(numeroOcorrencia==0){
			 Statement statement = null;
			 
			 statement = conn.createStatement();
			 
			 String insertTableSQL ="INSERT INTO px_albuns (ID, ID_cantor, ID_genero, nome_album, ano) VALUES (NULL, '"+id_cantor+"', '"+id_genero+"', '"+nome_album+"','"+ano+"')";

			 statement.executeUpdate(insertTableSQL);
			 
			 return true;
		 }
		 
		 else
			 return false;
		 
	 }
	
	
	 
	 public static void main(String[] argv) throws SQLException {
		 
		// System.out.println(efetuaLogin("contato.pauloxavier@gmail.com","qrtr123"));
		 	
		 System.out.println(incluiAlbum("1", "19", "Se Lugar", "2014"));

	 }

	
}
